var SiteMapManager = require('./manager');

module.exports = new SiteMapManager();
