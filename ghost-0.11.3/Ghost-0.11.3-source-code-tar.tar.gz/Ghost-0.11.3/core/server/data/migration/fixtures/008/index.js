module.exports = [
    require('./01-fix-sqlite-pg-format')
];
