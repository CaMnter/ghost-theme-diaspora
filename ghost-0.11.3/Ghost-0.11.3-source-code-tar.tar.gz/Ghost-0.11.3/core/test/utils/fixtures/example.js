
module.exports = {
    answer: 42
};
