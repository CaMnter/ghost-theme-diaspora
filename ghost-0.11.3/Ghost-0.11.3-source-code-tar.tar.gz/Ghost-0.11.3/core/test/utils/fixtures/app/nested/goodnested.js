/*jshint unused:false*/
var lib = require('../goodlib.js');

module.exports = {
    other: 42
};
