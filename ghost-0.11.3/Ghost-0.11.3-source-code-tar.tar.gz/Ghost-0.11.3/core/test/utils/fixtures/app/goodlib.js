module.exports = {
    util: function () {
        return 42;
    }
};
