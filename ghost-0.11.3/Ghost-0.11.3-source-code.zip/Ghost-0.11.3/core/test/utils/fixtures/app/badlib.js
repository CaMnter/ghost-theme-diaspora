var knex = require('knex');

module.exports = {
    knex: knex
};
